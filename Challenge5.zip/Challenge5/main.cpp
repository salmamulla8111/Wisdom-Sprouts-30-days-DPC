#include <iostream>
using namespace std;
int getPairsCount(int arr[], int n, int K)
{
	int count = 0;
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
			if (arr[i] + arr[j] == K)
				count++;

	return count;
}
int main()
{
    cout<<"Test Case 1:"<<endl;
	int arr[] = { 1,2,3,4,5};
	int n = sizeof(arr) / sizeof(arr[0]);
	int K = 6;
	cout << "Count of pairs is "<< getPairsCount(arr, n, K);
	cout<<endl;
	int arr1[] = { 3,1,4,2,5};
	cout<<"Test Case 2: "<<endl;
	int n1 = sizeof(arr1) / sizeof(arr1[0]);
	int K1 = 5;
	cout << "Count of pairs is "<< getPairsCount(arr1, n1, K1);
	cout<<endl;
	int arr2[] = {2,2,2,2,2};
	cout<<"Test Case 3: "<<endl;
	int n2 = sizeof(arr2) / sizeof(arr2[0]);
	int K2 = 4;
	cout << "Count of pairs is "<< getPairsCount(arr2, n2, K2);
	cout<<endl;
	int arr3[] = {10,20,30,40,50};
	cout<<"Test Case 4: "<<endl;
	int n3 = sizeof(arr3) / sizeof(arr3[0]);
	int K3 = 60;
	cout << "Count of pairs is "<< getPairsCount(arr3, n3, K3);
	cout<<endl;
	int arr4[] = { 1,3,5,7,9};
	cout<<"Test Case 5: "<<endl;
	int n4 = sizeof(arr4) / sizeof(arr4[0]);
	int K4 = 10;
	cout << "Count of pairs is "<< getPairsCount(arr4, n4, K4);
	cout<<endl;
	int arr5[] = {0,0,0,0,0};
	cout<<"Test Case 6: "<<endl;
	int n5 = sizeof(arr5) / sizeof(arr5[0]);
	int K5 = 10;
	cout << "Count of pairs is "<< getPairsCount(arr5, n5, K5);
	cout<<endl;
	int arr6[] = {5,10,15,20};
	cout<<"Test Case 7: "<<endl;
	int n6 = sizeof(arr6) / sizeof(arr6[0]);
	int K6 = 25;
	cout << "Count of pairs is "<< getPairsCount(arr6, n6, K6);
	cout<<endl;
	int arr7[] = {1,2,3,4,5};
	cout<<"Test Case 8: "<<endl;
	int n7 = sizeof(arr7) / sizeof(arr7[0]);
	int K7 = 9;
	cout << "Count of pairs is "<< getPairsCount(arr7, n7, K7);
	cout<<endl;
	int arr8[] = {9,4,6,3,2,1};
	cout<<"Test Case 9: "<<endl;
	int n8 = sizeof(arr8) / sizeof(arr8[0]);
	int K8 = 9;
	cout << "Count of pairs is "<< getPairsCount(arr8, n8, K8);
	cout<<endl;
	int arr9[] = {5,10,15,20,25,30};
	cout<<"Test Case 10: "<<endl;
	int n9 = sizeof(arr9) / sizeof(arr9[0]);
	int K9 = 35;
	cout << "Count of pairs is "<< getPairsCount(arr9, n9, K9);
	cout<<endl;

	return 0;
}

