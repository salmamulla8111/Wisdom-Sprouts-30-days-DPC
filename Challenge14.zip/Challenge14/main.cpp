#include <iostream>
#include <string>
#include <unordered_set>
using namespace std;
unordered_set<string> findDistinctSubstrings(string str, int k)
{
    unordered_set<string> result;
    for (int i = 0; i < str.length() - k + 1; i++)
    {        unordered_set<char> chars;
         for (int j = i; j < str.length() && chars.size() <= k; j++)
        {
            chars.insert(str[j]);
            if (chars.size() == k)
            {
                result.insert(str.substr(i, j - i + 1));
            }
        }
    }
    return result;
}
int main()
{
    string str = "abcadce";
    int k = 4;
    unordered_set<string> result = findDistinctSubstrings(str, k);
    for (string s: result) {
        cout << s << endl;
    }
    return 0;
}
