#include <iostream>
using namespace std;

void rearrangeElements(int arr[], int size){
    int i, j = 0;
    for(i = 0; i < size; i++){
        if(arr[i] < 0){
            if(i != j){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            j++;
        }
    }
}

int main(){
    int numElements, i;
    cout << "Enter the number of elements: " << endl;
    cin >> numElements;
    int myArray[numElements];
    cout << "Enter the array elements: " << endl;
    for(i = 0; i < numElements; i++){
        cin >> myArray[i];
    }

    cout << "Original array is: " << endl;
    for(i = 0; i < numElements; i++){
        cout << myArray[i] << " ";
    }
    cout << endl;

    rearrangeElements(myArray, numElements);

    cout << "Rearranged array is: " << endl;
    for(i = 0; i < numElements; i++){
        cout << myArray[i] << " ";
    }
    cout << endl;
    return 0;
}
