import java.util.Arrays;
class Main
{
    // Function to left-rotate an array by one position
    public static void leftRotateByOne(int[] arr)
    {
        int first = arr[0];
        for (int i = 0; i < arr.length - 1; i++) {
            arr[i] = arr[i + 1];
        }
        arr[arr.length - 1] = first;
    }

    // Function to left-rotate an array by `r` positions
    public static void leftRotate(int[] arr, int r)
    {
        // base case: invalid input
        if (r < 0 || r >= arr.length) {
            return;
        }

        for (int i = 0; i < r; i++) {
            leftRotateByOne(arr);
        }
    }

    public static void main(String[] args)
    {
        int[] arr = { 1, 2, 3, 4, 5 };
        int r = 2;
        leftRotate(arr, r);
        System.out.println(Arrays.toString(arr));
        int[] arr1 = { 10, 20, 30, 40, 50 };
        int r1 = 3;
        leftRotate(arr1, r1);
        System.out.println(Arrays.toString(arr1));
        int[] arr2 = { 3, 6, 9, 12, 15 };
        int r2 = 4;
        leftRotate(arr2, r2);
        System.out.println(Arrays.toString(arr2));
        int[] arr3 = { 5, 10, 15, 20, 25, 30 };
        int r3 = 1;
        leftRotate(arr3, r3);
        System.out.println(Arrays.toString(arr3));
        int[] arr4 = { 1, 2, 3, 4, 5, 6, 7};
        int r4 = 7;
        leftRotate(arr4, r4);
        System.out.println(Arrays.toString(arr4));
        int[] arr5 = { 8, 6, 4, 2, 0};
        int r5 = 5;
        leftRotate(arr5, r5);
        System.out.println(Arrays.toString(arr5));
        int[] arr6 = { 1, 3, 5, 7, 9};
        int r6 = 0;
        leftRotate(arr6, r6);
        System.out.println(Arrays.toString(arr6));
        int[] arr7 = { 1,2,3,4,5,6};
        int r7 = 6;
        leftRotate(arr7, r7);
        System.out.println(Arrays.toString(arr7));
        int[] arr8 = { 2,4,6,8};
        int r8 = 1;
        leftRotate(arr8, r8);
        System.out.println(Arrays.toString(arr8));
        int[] arr9 = { 7, 5, 3, 1};
        int r9 = 3;
        leftRotate(arr9, r9);
        System.out.println(Arrays.toString(arr9));


    }
}